// server.js
// Delivery site backend.
//
// The important behaviour the developer-mode panel relies on:
//   - Every category ("grocery", "restaurants", "home-items", "join-us") is a
//     real folder under /shop.
//   - Adding an item through the developer panel creates a real subfolder for
//     that item, saves the uploaded picture into it, writes an item.json data
//     file, and WRITES a self-contained item.html template file into that
//     same subfolder, styled with that category's colors.
//   - Editing an item's price/name later re-writes item.json and
//     regenerates item.html so the on-disk code always matches the data.
//
// This is meant to be run locally (`npm install && npm start`) while you
// build out the catalog, then the whole /shop folder + /public folder can be
// copied to your public host as-is (they're already static files).

const express = require("express");
const multer = require("multer");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

const DEV_CODE = "5050"; // developer-mode access code

const SHOP_DIR = path.join(__dirname, "shop");
const PUBLIC_DIR = path.join(__dirname, "public");
const ORDERS_DIR = path.join(__dirname, "orders");

if (!fs.existsSync(ORDERS_DIR)) fs.mkdirSync(ORDERS_DIR, { recursive: true });

// The four fixed categories and their color palettes.
// These MUST stay in sync with the CATEGORY_COLORS object in public/app.js.
const CATEGORIES = {
  grocery: { label: "Groceries", colors: ["#8F2635", "#829477"] },
  restaurants: { label: "Restaurants", colors: ["#8F2635"] },
  "home-items": { label: "Home Items", colors: ["#829477"] },
  "join-us": { label: "Join Us", colors: ["#A9AD78"] },
};

// Make sure every category folder exists on boot.
for (const cat of Object.keys(CATEGORIES)) {
  const dir = path.join(SHOP_DIR, cat);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

app.use(express.json());
app.use(express.static(PUBLIC_DIR));
app.use("/shop", express.static(SHOP_DIR)); // serve saved images/templates directly

// ---------- helpers ----------

function slugify(name) {
  return String(name)
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")
    .slice(0, 60) || "item";
}

function isValidCategory(cat) {
  return Object.prototype.hasOwnProperty.call(CATEGORIES, cat);
}

// Builds the standalone item.html template that gets written to disk.
// This is the "template that the developer just adds pricing to" piece:
// the name + picture are locked in at creation time, price is filled in
// and this function is re-run to regenerate the file whenever it changes.
function renderItemTemplate(category, item) {
  const palette = CATEGORIES[category].colors;
  const primary = palette[0];
  const secondary = palette[1] || primary;
  const priceDisplay =
    item.price === "" || item.price === null || item.price === undefined
      ? "Price coming soon"
      : `${Number(item.price).toFixed(2)} EGP`;
  const descriptionBlock = item.description
    ? `<p class="description">${escapeHtml(item.description)}</p>`
    : "";

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${escapeHtml(item.name)} — ${CATEGORIES[category].label}</title>
<style>
  :root {
    --primary: ${primary};
    --secondary: ${secondary};
    --white: #FFFFFF;
  }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    background: linear-gradient(160deg, var(--primary), var(--secondary));
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 24px;
  }
  .card {
    background: var(--white);
    border-radius: 18px;
    max-width: 360px;
    width: 100%;
    overflow: hidden;
    box-shadow: 0 20px 45px rgba(0,0,0,0.25);
  }
  .card img {
    width: 100%;
    height: 240px;
    object-fit: cover;
    display: block;
    background: #eee;
  }
  .card-body { padding: 20px; }
  .card-body h1 {
    margin: 0 0 8px;
    font-size: 1.4rem;
    color: #1a1a1a;
  }
  .description {
    color: #555;
    font-size: 0.9rem;
    margin: 10px 0;
  }
  .price {
    display: inline-block;
    margin-top: 6px;
    padding: 6px 14px;
    border-radius: 999px;
    background: var(--primary);
    color: var(--white);
    font-weight: 600;
  }
  .category-tag {
    font-size: 0.8rem;
    color: var(--secondary);
    font-weight: 600;
  }
</style>
</head>
<body>
  <div class="card">
    <img src="${escapeHtml(item.image)}" alt="${escapeHtml(item.name)}">
    <div class="card-body">
      <div class="category-tag">${CATEGORIES[category].label}</div>
      <h1>${escapeHtml(item.name)}</h1>
      ${item.subcategory ? `<div style="color:#b5b0a6;font-size:.8rem;margin-top:-6px">${escapeHtml(item.subcategory)}</div>` : ""}
      ${descriptionBlock}
      <span class="price">${priceDisplay}</span>
      ${item.sizes && item.sizes.length > 1 ? `<div style="margin-top:10px;color:#6f6a60;font-size:.85rem">${item.sizes.map((z) => `${escapeHtml(z.label)}: ${z.price} EGP`).join(" &middot; ")}</div>` : ""}
    </div>
  </div>
</body>
</html>
`;
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function writeItemFiles(category, slug, item) {
  const itemDir = path.join(SHOP_DIR, category, slug);
  fs.mkdirSync(itemDir, { recursive: true });
  fs.writeFileSync(
    path.join(itemDir, "item.json"),
    JSON.stringify(item, null, 2)
  );
  fs.writeFileSync(
    path.join(itemDir, "item.html"),
    renderItemTemplate(category, item)
  );
}

function readItem(category, slug) {
  const file = path.join(SHOP_DIR, category, slug, "item.json");
  if (!fs.existsSync(file)) return null;
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function listItems(category) {
  const catDir = path.join(SHOP_DIR, category);
  if (!fs.existsSync(catDir)) return [];
  return fs
    .readdirSync(catDir, { withFileTypes: true })
    .filter((d) => d.isDirectory())
    .map((d) => {
      const item = readItem(category, d.name);
      return item ? { ...item, slug: d.name } : null;
    })
    .filter(Boolean);
}

// multer: store uploaded pictures straight into a tmp spot, we move them once we know the slug
const upload = multer({ dest: path.join(__dirname, ".uploads") });

// ---------- routes ----------

app.get("/api/categories", (req, res) => {
  res.json(CATEGORIES);
});

app.post("/api/verify-dev-code", (req, res) => {
  const { code } = req.body || {};
  res.json({ ok: code === DEV_CODE });
});

app.get("/api/shop/:category", (req, res) => {
  const { category } = req.params;
  if (!isValidCategory(category)) return res.status(404).json({ error: "Unknown category" });
  if (category === "restaurants") {
    return res.status(400).json({ error: "Restaurants are grouped by restaurant profile — use /api/restaurants" });
  }
  res.json(listItems(category));
});

// ---------- restaurants: profile subfolder + menu items nested inside it ----------
//
// shop/restaurants/<restaurant-slug>/profile.json + profile.html   (the restaurant "page")
// shop/restaurants/<restaurant-slug>/<item-slug>/item.json + item.html   (a menu item)

const RESTAURANTS_DIR = path.join(SHOP_DIR, "restaurants");

function restaurantDir(slug) {
  return path.join(RESTAURANTS_DIR, slug);
}

function readRestaurantProfile(slug) {
  const file = path.join(restaurantDir(slug), "profile.json");
  if (!fs.existsSync(file)) return null;
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function listRestaurants() {
  if (!fs.existsSync(RESTAURANTS_DIR)) return [];
  return fs
    .readdirSync(RESTAURANTS_DIR, { withFileTypes: true })
    .filter((d) => d.isDirectory())
    .map((d) => {
      const profile = readRestaurantProfile(d.name);
      return profile ? { ...profile, slug: d.name } : null;
    })
    .filter(Boolean);
}

function renderRestaurantProfileTemplate(profile) {
  const [primary] = CATEGORIES.restaurants.colors;
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${escapeHtml(profile.name)} — Madina Delivery</title>
<style>
  :root { --primary: ${primary}; --white: #FFFFFF; }
  * { box-sizing: border-box; }
  body { margin:0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: var(--white); }
  .hero { height: 220px; background: var(--primary); display:flex; align-items:flex-end; overflow:hidden; }
  .hero img { width:100%; height:100%; object-fit:cover; opacity:0.85; }
  .name { padding: 18px 20px; color: var(--primary); }
  .name h1 { margin: 0; }
  .note { padding: 0 20px 20px; color:#666; font-size:0.9rem; }
</style>
</head>
<body>
  <div class="hero">${profile.image ? `<img src="${escapeHtml(profile.image)}" alt="${escapeHtml(profile.name)}">` : ""}</div>
  <div class="name"><h1>${escapeHtml(profile.name)}</h1></div>
  <p class="note">This restaurant's menu items live in their own subfolders next to this file.</p>
</body>
</html>
`;
}

function writeRestaurantProfileFiles(slug, profile) {
  const dir = restaurantDir(slug);
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, "profile.json"), JSON.stringify(profile, null, 2));
  fs.writeFileSync(path.join(dir, "profile.html"), renderRestaurantProfileTemplate(profile));
}

app.get("/api/restaurants", (req, res) => {
  res.json(listRestaurants());
});

app.post("/api/restaurants", upload.single("image"), (req, res) => {
  const { devCode, name } = req.body || {};
  if (devCode !== DEV_CODE) {
    if (req.file) fs.unlinkSync(req.file.path);
    return res.status(403).json({ error: "Invalid developer code" });
  }
  if (!name || !name.trim()) {
    if (req.file) fs.unlinkSync(req.file.path);
    return res.status(400).json({ error: "Restaurant name is required" });
  }

  const slug = slugify(name);
  const dir = restaurantDir(slug);
  fs.mkdirSync(dir, { recursive: true });

  let imageFilename = "";
  if (req.file) {
    const ext = path.extname(req.file.originalname) || ".jpg";
    imageFilename = "profile-picture" + ext;
    fs.renameSync(req.file.path, path.join(dir, imageFilename));
  }

  const profile = { name: name.trim(), image: imageFilename };
  writeRestaurantProfileFiles(slug, profile);
  res.json({ ...profile, slug });
});

app.delete("/api/restaurants/:slug", (req, res) => {
  const { slug } = req.params;
  const { devCode } = req.body || {};
  if (devCode !== DEV_CODE) return res.status(403).json({ error: "Invalid developer code" });
  const dir = restaurantDir(slug);
  if (!fs.existsSync(dir)) return res.status(404).json({ error: "Restaurant not found" });
  fs.rmSync(dir, { recursive: true, force: true });
  res.json({ ok: true });
});

// Menu items nested inside a restaurant's own folder
function listRestaurantItems(restaurantSlug) {
  const dir = restaurantDir(restaurantSlug);
  if (!fs.existsSync(dir)) return [];
  return fs
    .readdirSync(dir, { withFileTypes: true })
    .filter((d) => d.isDirectory())
    .map((d) => {
      const file = path.join(dir, d.name, "item.json");
      if (!fs.existsSync(file)) return null;
      return { ...JSON.parse(fs.readFileSync(file, "utf8")), slug: d.name };
    })
    .filter(Boolean)
    .sort((a, b) => (a.subcategory || "").localeCompare(b.subcategory || "") || a.name.localeCompare(b.name));
}

app.get("/api/restaurants/:slug/items", (req, res) => {
  const { slug } = req.params;
  if (!readRestaurantProfile(slug)) return res.status(404).json({ error: "Restaurant not found" });
  res.json(listRestaurantItems(slug));
});

app.post("/api/restaurants/:slug/items", upload.single("image"), (req, res) => {
  const { slug } = req.params;
  const { devCode, name, price, description } = req.body || {};

  if (devCode !== DEV_CODE) {
    if (req.file) fs.unlinkSync(req.file.path);
    return res.status(403).json({ error: "Invalid developer code" });
  }
  if (!readRestaurantProfile(slug)) {
    if (req.file) fs.unlinkSync(req.file.path);
    return res.status(404).json({ error: "Restaurant not found" });
  }
  if (!name || !name.trim()) {
    if (req.file) fs.unlinkSync(req.file.path);
    return res.status(400).json({ error: "Item name is required" });
  }

  const itemSlug = slugify(name);
  const itemDir = path.join(restaurantDir(slug), itemSlug);
  fs.mkdirSync(itemDir, { recursive: true });

  let imageFilename = "";
  if (req.file) {
    const ext = path.extname(req.file.originalname) || ".jpg";
    imageFilename = "picture" + ext;
    fs.renameSync(req.file.path, path.join(itemDir, imageFilename));
  }

  const item = {
    name: name.trim(),
    price: price === undefined || price === "" ? "" : Number(price),
    image: imageFilename,
    description: description ? String(description).trim() : "",
    category: "restaurants",
    restaurant: slug,
    subcategory: req.body.subcategory ? String(req.body.subcategory).trim() : "",
  };
  if (req.body.sizes) {
    try {
      const sizes = JSON.parse(req.body.sizes).map((z) => ({ label: String(z.label), price: Number(z.price) }));
      if (sizes.length) { item.sizes = sizes; item.price = sizes[0].price; }
    } catch (e) { /* ignore bad sizes */ }
  }

  fs.writeFileSync(path.join(itemDir, "item.json"), JSON.stringify(item, null, 2));
  fs.writeFileSync(path.join(itemDir, "item.html"), renderItemTemplate("restaurants", item));

  res.json({ ...item, slug: itemSlug });
});

app.patch("/api/restaurants/:slug/items/:itemSlug", (req, res) => {
  const { slug, itemSlug } = req.params;
  const { devCode, name, price, description } = req.body || {};
  if (devCode !== DEV_CODE) return res.status(403).json({ error: "Invalid developer code" });

  const file = path.join(restaurantDir(slug), itemSlug, "item.json");
  if (!fs.existsSync(file)) return res.status(404).json({ error: "Item not found" });
  const existing = JSON.parse(fs.readFileSync(file, "utf8"));

  const updated = {
    ...existing,
    name: name !== undefined && name !== "" ? name.trim() : existing.name,
    price: price !== undefined && price !== "" ? Number(price) : existing.price,
    description: description !== undefined ? String(description).trim() : existing.description || "",
  };

  fs.writeFileSync(file, JSON.stringify(updated, null, 2));
  fs.writeFileSync(
    path.join(restaurantDir(slug), itemSlug, "item.html"),
    renderItemTemplate("restaurants", updated)
  );
  res.json({ ...updated, slug: itemSlug });
});

app.delete("/api/restaurants/:slug/items/:itemSlug", (req, res) => {
  const { slug, itemSlug } = req.params;
  const { devCode } = req.body || {};
  if (devCode !== DEV_CODE) return res.status(403).json({ error: "Invalid developer code" });
  const dir = path.join(restaurantDir(slug), itemSlug);
  if (!fs.existsSync(dir)) return res.status(404).json({ error: "Item not found" });
  fs.rmSync(dir, { recursive: true, force: true });
  res.json({ ok: true });
});

// Create a new item: multipart form with fields name, price, image
app.post("/api/shop/:category", upload.single("image"), (req, res) => {
  const { category } = req.params;
  const { devCode, name, price, description } = req.body || {};

  if (devCode !== DEV_CODE) {
    if (req.file) fs.unlinkSync(req.file.path);
    return res.status(403).json({ error: "Invalid developer code" });
  }
  if (!isValidCategory(category)) {
    if (req.file) fs.unlinkSync(req.file.path);
    return res.status(404).json({ error: "Unknown category" });
  }
  if (category === "restaurants") {
    if (req.file) fs.unlinkSync(req.file.path);
    return res.status(400).json({ error: "Restaurants use /api/restaurants and /api/restaurants/:slug/items instead" });
  }
  if (!name || !name.trim()) {
    if (req.file) fs.unlinkSync(req.file.path);
    return res.status(400).json({ error: "Item name is required" });
  }

  const slug = slugify(name);
  const itemDir = path.join(SHOP_DIR, category, slug);
  fs.mkdirSync(itemDir, { recursive: true });

  let imageFilename = "";
  if (req.file) {
    const ext = path.extname(req.file.originalname) || ".jpg";
    imageFilename = "picture" + ext;
    fs.renameSync(req.file.path, path.join(itemDir, imageFilename));
  }

  const item = {
    name: name.trim(),
    price: price === undefined || price === "" ? "" : Number(price),
    image: imageFilename, // relative to /shop/<category>/<slug>/
    description: description ? String(description).trim() : "",
    category,
  };

  writeItemFiles(category, slug, item);
  res.json({ ...item, slug });
});

// Edit an existing item's name/price/description (regenerates item.html on disk)
app.patch("/api/shop/:category/:slug", (req, res) => {
  const { category, slug } = req.params;
  const { devCode, name, price, description } = req.body || {};

  if (devCode !== DEV_CODE) return res.status(403).json({ error: "Invalid developer code" });
  if (!isValidCategory(category)) return res.status(404).json({ error: "Unknown category" });
  if (category === "restaurants") return res.status(400).json({ error: "Use /api/restaurants/:slug/items/:itemSlug instead" });

  const existing = readItem(category, slug);
  if (!existing) return res.status(404).json({ error: "Item not found" });

  const updated = {
    ...existing,
    name: name !== undefined && name !== "" ? name.trim() : existing.name,
    price: price !== undefined && price !== "" ? Number(price) : existing.price,
    description: description !== undefined ? String(description).trim() : existing.description || "",
  };

  writeItemFiles(category, slug, updated);
  res.json({ ...updated, slug });
});

app.delete("/api/shop/:category/:slug", (req, res) => {
  const { category, slug } = req.params;
  const { devCode } = req.body || {};
  if (devCode !== DEV_CODE) return res.status(403).json({ error: "Invalid developer code" });
  if (category === "restaurants") return res.status(400).json({ error: "Use /api/restaurants/:slug/items/:itemSlug instead" });

  const itemDir = path.join(SHOP_DIR, category, slug);
  if (!fs.existsSync(itemDir)) return res.status(404).json({ error: "Item not found" });
  fs.rmSync(itemDir, { recursive: true, force: true });
  res.json({ ok: true });
});

// ---------- orders (checkout) ----------
//
// Placing an order writes a real order-<id>.json file under /orders — no
// payment processor is wired up here (this only records the order itself,
// pay-on-delivery style); plug in a real payment step before going live if
// you need one.

function generateOrderId() {
  const stamp = new Date().toISOString().replace(/[-:.TZ]/g, "").slice(0, 14);
  const rand = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `${stamp}-${rand}`;
}

app.post("/api/orders", (req, res) => {
  const { customer, items, total } = req.body || {};

  if (!customer || !customer.name || !customer.phone || !customer.address) {
    return res.status(400).json({ error: "Name, phone, and delivery address are required" });
  }
  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: "Cart is empty" });
  }

  const orderId = generateOrderId();
  const order = {
    orderId,
    placedAt: new Date().toISOString(),
    status: "received",
    customer: {
      name: String(customer.name).trim(),
      phone: String(customer.phone).trim(),
      address: String(customer.address).trim(),
      notes: customer.notes ? String(customer.notes).trim() : "",
    },
    items: items.map((it) => ({
      name: String(it.name || "").trim(),
      price: Number(it.price) || 0,
      qty: Number(it.qty) || 1,
    })),
    total: Number(total) || 0,
  };

  fs.writeFileSync(path.join(ORDERS_DIR, `order-${orderId}.json`), JSON.stringify(order, null, 2));
  res.json({ ok: true, orderId });
});

app.get("/api/orders/:orderId", (req, res) => {
  const file = path.join(ORDERS_DIR, `order-${req.params.orderId}.json`);
  if (!fs.existsSync(file)) return res.status(404).json({ error: "Order not found" });
  res.json(JSON.parse(fs.readFileSync(file, "utf8")));
});

// List every order (newest first). Gated by the same developer code, since
// order details are customer PII — pass it as a query param: /api/orders?devCode=5050
app.get("/api/orders", (req, res) => {
  if (req.query.devCode !== DEV_CODE) return res.status(403).json({ error: "Invalid developer code" });
  const orders = fs
    .readdirSync(ORDERS_DIR)
    .filter((f) => f.endsWith(".json"))
    .map((f) => JSON.parse(fs.readFileSync(path.join(ORDERS_DIR, f), "utf8")))
    .sort((a, b) => (a.placedAt < b.placedAt ? 1 : -1));
  res.json(orders);
});

const ORDER_STATUSES = ["received", "preparing", "out-for-delivery", "delivered", "cancelled"];

app.patch("/api/orders/:orderId", (req, res) => {
  const { devCode, status } = req.body || {};
  if (devCode !== DEV_CODE) return res.status(403).json({ error: "Invalid developer code" });
  if (!ORDER_STATUSES.includes(status)) return res.status(400).json({ error: "Invalid status" });

  const file = path.join(ORDERS_DIR, `order-${req.params.orderId}.json`);
  if (!fs.existsSync(file)) return res.status(404).json({ error: "Order not found" });

  const order = JSON.parse(fs.readFileSync(file, "utf8"));
  order.status = status;
  fs.writeFileSync(file, JSON.stringify(order, null, 2));
  res.json(order);
});

app.delete("/api/orders/:orderId", (req, res) => {
  const { devCode } = req.body || {};
  if (devCode !== DEV_CODE) return res.status(403).json({ error: "Invalid developer code" });

  const file = path.join(ORDERS_DIR, `order-${req.params.orderId}.json`);
  if (!fs.existsSync(file)) return res.status(404).json({ error: "Order not found" });
  fs.unlinkSync(file);
  res.json({ ok: true });
});

app.listen(PORT, () => {
  console.log(`Delivery site running at http://localhost:${PORT}`);
});
