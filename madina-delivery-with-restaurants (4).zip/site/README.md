# Madina Delivery

A responsive delivery storefront with a warm cream, burgundy and sage visual identity, a grocery hero, four photographic category cards (Groceries, Restaurants, Home Items, Join Us), a product grid, benefits section and a code-gated developer panel for managing shop items.

- Switching categories plays a light-color sweep animation across the button
  area, and every item/restaurant card slides up and fades in, staggered
  one after another.
- **Restaurants** is two levels deep: the developer first creates a
  restaurant profile (name + picture), then adds menu items *inside* that
  restaurant's own subfolder — `shop/restaurants/<restaurant>/<menu-item>/`.

## Run it locally

```
npm install
npm start
```

Then open http://localhost:3000

## How developer mode works

1. Choose **Developer** in the footer.
2. Enter the access code: `5050`
3. Pick a category.
   - **Grocery / Home Items / Join Us**: name the item, optionally set a
     price, upload a picture, then **Add item**.
   - **Restaurants**: first create a restaurant profile (name + picture),
     or pick an existing one — then add menu items *into* that restaurant.

When you add a grocery/home/join-us item, the server:

- Creates a real folder: `shop/<category>/<item-name>/`
- Saves the picture into that folder
- Writes `item.json` (the item's data)
- Writes `item.html` — a self-contained template page styled in that
  category's colors, using the name + picture you gave it

When you create a restaurant profile, the server creates
`shop/restaurants/<restaurant-name>/` with `profile.json` + `profile.html`.
Every menu item you then add for that restaurant creates its own subfolder
*inside* the restaurant's folder —
`shop/restaurants/<restaurant-name>/<menu-item-name>/` — with its own
`item.json` + `item.html`, just like the other categories.

Editing the price later (from the **Save** button in the developer panel)
updates `item.json` and **rewrites `item.html`** so the generated code on
disk always matches what you entered — that's the "self-sustaining" part:
editing in developer mode is what writes/updates the code.

## Before you go public

Everything under `public/` and `shop/` is plain static files (HTML/CSS/JS +
JSON + images), so once your catalog looks right locally you can upload the
whole project folder to your public host as-is. `server.js` only needs
Node.js to run — most hosts that support Node can run it directly with
`npm install && npm start`.

## Color palette

- Site base: warm cream `#FAF7F0` and white
- Primary accent: burgundy `#8F2635`
- Secondary accent: sage `#829477`
- Soft highlight: pale sage `#DFE2C6` and beige `#F2E7D6`

## Login button

The **Login** button links to `public/login.html`, a standalone page with
an email/password form, placeholder Terms of Service and Privacy Policy
text, and a required agreement checkbox. It isn't wired up to a real
account system yet — build your own login logic in the `<script>` at the
bottom of that file.

## Checkout

The cart's **Checkout** button goes to `public/checkout.html`, which reads
the cart out of `localStorage`, collects a name/phone/address, and submits
it to `POST /api/orders`. That endpoint writes a real
`orders/order-<id>.json` file and returns an order number, which the page
then shows as a confirmation. No payment processor is wired up — this is
pay-on-delivery style order capture; add a real payment step before going
live if you need one.


## Reference-matched visual redesign

The storefront homepage now uses a warm cream, burgundy and sage palette, a sticky navigation bar, grocery hero, four photographic category cards, a five-item starter grocery catalogue, a benefits strip and a dark footer. Fresh AI-generated visual assets are stored locally in `public/assets/images/`; the original archive's imagery is not reused for the new homepage. The starter grocery products are ordinary editable items and can be changed or removed from Developer mode (access code remains `5050`).
