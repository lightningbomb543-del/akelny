// public/app.js

// Keep this order + these colors in sync with server.js CATEGORIES.
const CATEGORY_ORDER = ["grocery", "restaurants", "home-items", "join-us"];
const CATEGORY_META = {
  grocery: { label: "Groceries", colors: ["#8F2635", "#829477"] },
  restaurants: { label: "Restaurants", colors: ["#8F2635", "#8F2635"] },
  "home-items": { label: "Home Items", colors: ["#829477", "#829477"] },
  "join-us": { label: "Join Us", colors: ["#A9AD78", "#829477"] },
};

let currentIndex = 0;
let devUnlocked = false;
let viewingRestaurant = null; // slug of the restaurant whose menu is open, or null

const categoryNameEl = document.getElementById("categoryName");
const itemsGridEl = document.getElementById("itemsGrid");
const themeSweepEl = document.getElementById("themeSweep");
const topbarGlowEl = document.getElementById("topbarGlow");
const backToRestaurantsBtn = document.getElementById("backToRestaurants");

function applyTheme(cat) {
  const [a, b] = CATEGORY_META[cat].colors;
  document.documentElement.style.setProperty("--theme-a", a);
  document.documentElement.style.setProperty("--theme-b", b);
  // Soft tint of the category color, used for the nav area's background.
  const n = parseInt(a.slice(1), 16);
  document.documentElement.style.setProperty(
    "--theme-soft",
    `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, 0.14)`
  );
}

// Restarts the light-color sweep + topbar glow pulse together.
function playThemeAnimations() {
  themeSweepEl.classList.remove("sweep-play");
  topbarGlowEl.classList.remove("glow-pulse");
  void themeSweepEl.offsetWidth; // force reflow so the animations can replay
  themeSweepEl.classList.add("sweep-play");
  topbarGlowEl.classList.add("glow-pulse");
}

const categoryButtons = document.querySelectorAll(".pillow-btn[data-category]");

function setActiveButton(cat) {
  categoryButtons.forEach((btn) => {
    const on = btn.dataset.category === cat;
    btn.classList.toggle("is-active", on);
    btn.setAttribute("aria-pressed", on ? "true" : "false");
  });
}

// Same behavior the wheel had: switch the theme, replay the animations, clear
// the search, and load that category's items (or the restaurant list).
function selectCategory(index) {
  removeChipBar();
  currentIndex = ((index % CATEGORY_ORDER.length) + CATEGORY_ORDER.length) % CATEGORY_ORDER.length;

  const cat = CATEGORY_ORDER[currentIndex];
  categoryNameEl.textContent = CATEGORY_META[cat].label;
  applyTheme(cat);
  setActiveButton(cat);
  playThemeAnimations();
  viewingRestaurant = null;
  backToRestaurantsBtn.classList.add("hidden");
  clearSearch();

  if (cat === "restaurants") {
    loadRestaurants();
  } else {
    loadItems(cat);
  }
}

categoryButtons.forEach((btn) => {
  btn.addEventListener("click", () => {
    selectCategory(CATEGORY_ORDER.indexOf(btn.dataset.category));
    document.getElementById("shop").scrollIntoView({ behavior: "smooth", block: "start" });
  });
});

// ---------- items grid (grocery / home-items / join-us) ----------

let currentFullList = []; // unfiltered list for whatever's currently shown, so search can re-filter from scratch
let currentRenderConfig = null; // { innerHtmlFn, emptyMessage, onClick, getBaseUrl } for the current view

async function loadItems(category) {
  itemsGridEl.innerHTML = "<p class='empty-state'>Loading…</p>";
  try {
    const res = await fetch(`/api/shop/${category}`);
    const items = await res.json();
    currentFullList = items;
    currentRenderConfig = {
      innerHtmlFn: (item) => `
        ${item.image ? `<img src="/shop/${item.category}/${item.slug}/${item.image}" alt="${escapeHtml(item.name)}">` : ""}
        <div class="item-body">
          <h3>${escapeHtml(item.name)}</h3>
          ${item.description ? `<p class="item-description">${escapeHtml(item.description)}</p>` : ""}
          <div class="item-card-footer">
            <span class="item-price">${priceLabel(item.price)}</span>
            <button type="button" class="add-to-cart-mini">Add to cart</button>
          </div>
        </div>
      `,
      emptyMessage: "No items yet in this category. The developer can add some from the Developer button above.",
      onClick: (item) => openItemDetail(item, `/shop/${item.category}/${item.slug}/`),
      getBaseUrl: (item) => `/shop/${item.category}/${item.slug}/`,
    };
    renderCurrentList();
  } catch (e) {
    itemsGridEl.innerHTML = "<p class='empty-state'>Could not load items right now.</p>";
  }
}

// ---------- restaurants: profile list, then menu items ----------

async function loadRestaurants() {
  removeChipBar();
  itemsGridEl.innerHTML = "<p class='empty-state'>Loading…</p>";
  backToRestaurantsBtn.classList.add("hidden");
  try {
    const res = await fetch("/api/restaurants");
    const restaurants = await res.json();
    currentFullList = restaurants;
    currentRenderConfig = {
      innerHtmlFn: (r) => `
        ${r.image ? `<img src="/shop/restaurants/${r.slug}/${r.image}" alt="${escapeHtml(r.name)}">` : ""}
        <div class="item-body"><h3>${escapeHtml(r.name)}</h3></div>
      `,
      emptyMessage: "No restaurants yet. The developer can add restaurant profiles from the Developer button above.",
      onClick: (r) => openRestaurantMenu(r.slug, r.name),
      getBaseUrl: null,
    };
    renderCurrentList();
  } catch (e) {
    itemsGridEl.innerHTML = "<p class='empty-state'>Could not load restaurants right now.</p>";
  }
}

let activeSub = "All";
function getChipBar() {
  let bar = document.getElementById("subChips");
  if (!bar) { bar = document.createElement("div"); bar.id = "subChips"; bar.className = "sub-chips"; itemsGridEl.parentNode.insertBefore(bar, itemsGridEl); }
  return bar;
}
function removeChipBar() { const b = document.getElementById("subChips"); if (b) b.remove(); }
function buildChipBar(items) {
  const subs = [...new Set(items.map((i) => i.subcategory).filter(Boolean))];
  if (subs.length < 2) { removeChipBar(); return; }
  const bar = getChipBar();
  bar.innerHTML = ["All", ...subs].map((s) => `<button type="button" class="sub-chip" data-sub="${escapeHtml(s)}">${escapeHtml(s)}</button>`).join("");
  bar.querySelectorAll(".sub-chip").forEach((btn) => btn.addEventListener("click", () => {
    const sec = [...itemsGridEl.querySelectorAll(".menu-section-head")].find((h) => h.dataset.sec === btn.dataset.sub);
    if (btn.dataset.sub === "All") window.scrollTo({ top: itemsGridEl.getBoundingClientRect().top + window.scrollY - 110, behavior: "smooth" });
    else if (sec) window.scrollTo({ top: sec.getBoundingClientRect().top + window.scrollY - 110, behavior: "smooth" });
  }));
}

async function openRestaurantMenu(slug, name) {
  activeSub = "All";
  viewingRestaurant = slug;
  categoryNameEl.textContent = name;
  backToRestaurantsBtn.classList.remove("hidden");
  itemsGridEl.innerHTML = "<p class='empty-state'>Loading menu…</p>";
  clearSearch();
  try {
    const res = await fetch(`/api/restaurants/${slug}/items`);
    const items = await res.json();
    currentFullList = items;
    buildChipBar(items);
    currentRenderConfig = {
      innerHtmlFn: (item) => `
        ${item.image ? `<img src="/shop/restaurants/${slug}/${item.slug}/${item.image}" alt="${escapeHtml(item.name)}">` : ""}
        <div class="item-body">
          <h3>${escapeHtml(item.name)}</h3>
          ${item.subcategory ? `<span class="item-sub">${escapeHtml(item.subcategory)}</span>` : ""}
          ${item.sizes && item.sizes.length > 1 ? `<div class="size-pills">${item.sizes.map((s, j) => `<button type="button" class="size-pill${j === (item._size || 0) ? " active" : ""}">${escapeHtml(s.label)}</button>`).join("")}</div>` : ""}
          ${item.description ? `<p class="item-description">${escapeHtml(item.description)}</p>` : ""}
          <div class="item-card-footer">
            <span class="item-price">${priceLabel(item.sizes && item.sizes.length ? item.sizes[item._size || 0].price : item.price)}</span>
            <button type="button" class="add-to-cart-mini">Add to cart</button>
          </div>
        </div>
      `,
      emptyMessage: "No menu items yet for this restaurant.",
      onClick: (item) => openItemDetail(resolveItem(item), `/shop/restaurants/${slug}/${item.slug}/`),
      getBaseUrl: (item) => `/shop/restaurants/${slug}/${item.slug}/`,
    };
    renderCurrentList();
  } catch (e) {
    itemsGridEl.innerHTML = "<p class='empty-state'>Could not load the menu right now.</p>";
  }
}

backToRestaurantsBtn.addEventListener("click", () => {
  viewingRestaurant = null;
  removeChipBar();
  categoryNameEl.textContent = CATEGORY_META.restaurants.label;
  backToRestaurantsBtn.classList.add("hidden");
  clearSearch();
  loadRestaurants();
});

// ---------- search ----------

const searchInputEl = document.getElementById("itemSearchInput");

function renderCurrentList() {
  const query = searchInputEl.value.trim().toLowerCase();
  const filtered = query
    ? currentFullList.filter((entry) => entry.name.toLowerCase().includes(query))
    : currentFullList;
  const cfg = currentRenderConfig;
  const emptyMessage = query && currentFullList.length
    ? `No matches for "${escapeHtml(searchInputEl.value.trim())}".`
    : cfg.emptyMessage;
  renderCards(filtered, cfg.innerHtmlFn, emptyMessage, cfg.onClick, cfg.getBaseUrl);
}

function clearSearch() {
  searchInputEl.value = "";
}

searchInputEl.addEventListener("input", () => {
  if (currentRenderConfig) renderCurrentList();
});

// ---------- shared card rendering with the staggered slide-in ----------

function renderCards(list, innerHtmlFn, emptyMessage, onClickFn, getBaseUrl) {
  if (!list.length) {
    itemsGridEl.innerHTML = `<p class="empty-state">${emptyMessage}</p>`;
    return;
  }
  const grouped = viewingRestaurant && list.some((e) => e.subcategory);
  let lastSub = null;
  itemsGridEl.innerHTML = list.map((entry, i) => {
    let head = "";
    if (grouped && entry.subcategory !== lastSub) {
      lastSub = entry.subcategory;
      head = `<div class="menu-section-head" data-sec="${escapeHtml(lastSub || "")}"><h2>${escapeHtml(lastSub || "Other")}</h2></div>`;
    }
    return `${head}
    <div class="item-card" style="--delay:${Math.min(i, 12) * 70}ms" data-index="${i}">
      ${innerHtmlFn(entry)}
    </div>`;
  }).join("");

  itemsGridEl.querySelectorAll(".item-card").forEach((card, i) => {
    card.querySelectorAll(".size-pill").forEach((pill, j) => pill.addEventListener("click", (e) => {
      e.stopPropagation();
      list[i]._size = j;
      card.querySelectorAll(".size-pill").forEach((p, k) => p.classList.toggle("active", k === j));
      card.querySelector(".item-price").textContent = priceLabel(list[i].sizes[j].price);
    }));
  });

  if (onClickFn) {
    itemsGridEl.querySelectorAll(".item-card").forEach((card, i) => {
      card.addEventListener("click", () => onClickFn(list[i]));
    });
  }

  if (getBaseUrl) {
    itemsGridEl.querySelectorAll(".add-to-cart-mini").forEach((btn, i) => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation(); // don't also trigger the card's own click (the detail popup)
        const entry = list[i];
        addToCart({ ...resolveItem(entry), imageBaseUrl: getBaseUrl(entry) });
        const original = btn.textContent;
        btn.textContent = "Added!";
        btn.disabled = true;
        window.setTimeout(() => { btn.textContent = original; btn.disabled = false; }, 900);
      });
    });
  }
}

function priceLabel(price) {
  return price === "" || price === null || price === undefined ? "Price coming soon" : Number(price).toFixed(2) + " EGP";
}

function escapeHtml(str) {
  return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

// ---------- modal helpers ----------

function openModal(id) { document.getElementById(id).classList.remove("hidden"); }
function closeModal(id) { document.getElementById(id).classList.add("hidden"); }

document.querySelectorAll("[data-close]").forEach((btn) => {
  btn.addEventListener("click", () => closeModal(btn.dataset.close));
});

// ---------- item detail popup + add to cart ----------

let detailItem = null; // the item currently shown in the detail popup, plus its image base URL

function resolveItem(entry) {
  if (!entry.sizes || !entry.sizes.length) return entry;
  const s = entry.sizes[entry._size || 0];
  return { ...entry, name: `${entry.name} (${s.label})`, price: s.price, cartSlug: `${entry.slug}-${s.label.toLowerCase().replace(/\W+/g, "")}` };
}

function openItemDetail(item, imageBaseUrl) {
  detailItem = { ...item, imageBaseUrl };
  document.getElementById("detailImage").src = item.image ? imageBaseUrl + item.image : "";
  document.getElementById("detailImage").alt = item.name;
  document.getElementById("detailName").textContent = item.name;
  document.getElementById("detailDescription").textContent = item.description || "";
  document.getElementById("detailPrice").textContent = priceLabel(item.price);
  document.getElementById("addToCartStatus").textContent = "";
  openModal("itemDetailModal");
}

document.getElementById("addToCartBtn").addEventListener("click", () => {
  if (!detailItem) return;
  addToCart(detailItem);
  document.getElementById("addToCartStatus").textContent = "Added to cart.";
});

// ---------- cart ----------

let cart = [];
try {
  cart = JSON.parse(localStorage.getItem("madinaCart") || "[]");
} catch (e) {
  cart = [];
}

function cartKey(item) {
  return `${item.category}:${item.restaurant || ""}:${item.cartSlug || item.slug}`;
}

function saveCart() {
  try { localStorage.setItem("madinaCart", JSON.stringify(cart)); } catch (e) { /* ignore */ }
  updateCartBadge();
}

function addToCart(item) {
  const key = cartKey(item);
  const existing = cart.find((c) => c.key === key);
  if (existing) {
    existing.qty += 1;
  } else {
    cart.push({
      key,
      name: item.name,
      price: item.price === "" ? 0 : Number(item.price) || 0,
      image: item.image ? item.imageBaseUrl + item.image : "",
      qty: 1,
    });
  }
  saveCart();
}

function updateCartBadge() {
  const count = cart.reduce((sum, c) => sum + c.qty, 0);
  const badge = document.getElementById("cartCount");
  badge.textContent = count;
  badge.classList.toggle("hidden", count === 0);
}

function renderCart() {
  const cartItemsEl = document.getElementById("cartItems");
  if (!cart.length) {
    cartItemsEl.innerHTML = "<p class='empty-state'>Your cart is empty.</p>";
  } else {
    cartItemsEl.innerHTML = cart.map((c) => `
      <div class="cart-item-row" data-key="${c.key}">
        ${c.image ? `<img src="${c.image}" alt="${escapeHtml(c.name)}">` : ""}
        <div class="cart-item-info">
          <div class="name">${escapeHtml(c.name)}</div>
          <div class="price">${c.price ? "$" + c.price.toFixed(2) : "Price coming soon"}</div>
        </div>
        <div class="qty-controls">
          <button type="button" class="qty-minus">−</button>
          <span>${c.qty}</span>
          <button type="button" class="qty-plus">+</button>
        </div>
      </div>
    `).join("");

    cartItemsEl.querySelectorAll(".qty-plus").forEach((btn) => {
      btn.addEventListener("click", () => {
        const key = btn.closest(".cart-item-row").dataset.key;
        const c = cart.find((x) => x.key === key);
        if (c) { c.qty += 1; saveCart(); renderCart(); }
      });
    });
    cartItemsEl.querySelectorAll(".qty-minus").forEach((btn) => {
      btn.addEventListener("click", () => {
        const key = btn.closest(".cart-item-row").dataset.key;
        const c = cart.find((x) => x.key === key);
        if (!c) return;
        c.qty -= 1;
        if (c.qty <= 0) cart = cart.filter((x) => x.key !== key);
        saveCart(); renderCart();
      });
    });
  }

  const total = cart.reduce((sum, c) => sum + c.price * c.qty, 0);
  document.getElementById("cartTotal").textContent = "$" + total.toFixed(2);

  const checkoutBtn = document.getElementById("checkoutBtn");
  checkoutBtn.classList.toggle("pill-btn--disabled", cart.length === 0);
}

document.getElementById("cartBtn").addEventListener("click", () => {
  renderCart();
  openModal("cartModal");
});

document.getElementById("checkoutBtn").addEventListener("click", (e) => {
  if (cart.length === 0) e.preventDefault();
});

updateCartBadge();

// ---------- contact button (placeholder — details added later) ----------

document.getElementById("contactBtn").addEventListener("click", () => openModal("contactModal"));

// ---------- developer code gate ----------

document.getElementById("devBtn").addEventListener("click", () => {
  if (devUnlocked) {
    openDevPanel();
  } else {
    document.getElementById("devCodeError").classList.add("hidden");
    document.getElementById("devCodeInput").value = "";
    openModal("devCodeModal");
  }
});

document.getElementById("devCodeForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const code = document.getElementById("devCodeInput").value.trim();
  const res = await fetch("/api/verify-dev-code", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ code }),
  });
  const data = await res.json();
  if (data.ok) {
    devUnlocked = true;
    window.__devCode = code; // kept only for this session, used to authorize add/edit/delete calls
    closeModal("devCodeModal");
    openDevPanel();
  } else {
    document.getElementById("devCodeError").classList.remove("hidden");
  }
});

// ---------- developer panel ----------

const itemCategorySelect = document.getElementById("itemCategory");
const restaurantPicker = document.getElementById("restaurantPicker");
const restaurantSelect = document.getElementById("restaurantSelect");
const newRestaurantFields = document.getElementById("newRestaurantFields");
const menuItemsHeading = document.getElementById("menuItemsHeading");
const itemNameLabel = document.getElementById("itemNameLabel");
const addItemForm = document.getElementById("addItemForm");
const addItemSubmit = document.getElementById("addItemSubmit");
const devListHeading = document.getElementById("devListHeading");

let selectedRestaurantSlug = ""; // "" means "create a new one"

function openDevPanel() {
  itemCategorySelect.value = CATEGORY_ORDER[currentIndex] === "restaurants" ? "restaurants" : CATEGORY_ORDER[currentIndex];
  onCategoryChange();
  openModal("devPanelModal");
}

itemCategorySelect.addEventListener("change", onCategoryChange);

function onCategoryChange() {
  const category = itemCategorySelect.value;
  if (category === "restaurants") {
    restaurantPicker.classList.remove("hidden");
    populateRestaurantSelect();
  } else {
    restaurantPicker.classList.add("hidden");
    itemNameLabel.firstChild.textContent = "Item name";
    addItemForm.classList.remove("hidden");
    addItemSubmit.textContent = "Add item";
    devListHeading.textContent = "Existing items in this category";
    refreshDevItemsList();
  }
}

async function populateRestaurantSelect() {
  const res = await fetch("/api/restaurants");
  const restaurants = await res.json();
  restaurantSelect.innerHTML = `<option value="">+ New restaurant profile</option>` +
    restaurants.map((r) => `<option value="${r.slug}">${escapeHtml(r.name)}</option>`).join("");
  restaurantSelect.value = "";
  onRestaurantSelectionChange();
}

restaurantSelect.addEventListener("change", onRestaurantSelectionChange);

function onRestaurantSelectionChange() {
  selectedRestaurantSlug = restaurantSelect.value;
  if (selectedRestaurantSlug) {
    newRestaurantFields.classList.add("hidden");
    menuItemsHeading.classList.remove("hidden");
    itemNameLabel.firstChild.textContent = "Menu item name";
    addItemForm.classList.remove("hidden");
    addItemSubmit.textContent = "Add menu item";
    devListHeading.textContent = "Menu items for this restaurant";
    refreshRestaurantDevItemsList();
  } else {
    newRestaurantFields.classList.remove("hidden");
    menuItemsHeading.classList.add("hidden");
    addItemForm.classList.add("hidden");
    devListHeading.textContent = "Existing restaurants";
    refreshRestaurantProfilesList();
  }
}

document.getElementById("createRestaurantBtn").addEventListener("click", async () => {
  const statusEl = document.getElementById("createRestaurantStatus");
  const name = document.getElementById("restaurantName").value;
  const imageInput = document.getElementById("restaurantImage");
  if (!name.trim()) { statusEl.textContent = "Enter a restaurant name."; return; }
  if (!imageInput.files[0]) { statusEl.textContent = "Add a picture."; return; }

  statusEl.textContent = "Creating…";
  const form = new FormData();
  form.append("devCode", window.__devCode);
  form.append("name", name);
  form.append("image", imageInput.files[0]);

  const res = await fetch("/api/restaurants", { method: "POST", body: form });
  if (res.ok) {
    const restaurant = await res.json();
    statusEl.textContent = "Restaurant profile created.";
    document.getElementById("restaurantName").value = "";
    imageInput.value = "";
    await populateRestaurantSelect();
    restaurantSelect.value = restaurant.slug;
    onRestaurantSelectionChange();
    if (CATEGORY_ORDER[currentIndex] === "restaurants" && !viewingRestaurant) loadRestaurants();
  } else {
    const data = await res.json().catch(() => ({}));
    statusEl.textContent = data.error || "Could not create restaurant.";
  }
});

async function refreshRestaurantProfilesList() {
  const listEl = document.getElementById("devItemsList");
  listEl.innerHTML = "Loading…";
  const res = await fetch("/api/restaurants");
  const restaurants = await res.json();
  if (!restaurants.length) {
    listEl.innerHTML = "<p class='form-note'>No restaurants yet.</p>";
    return;
  }
  listEl.innerHTML = restaurants.map((r) => `
    <div class="dev-item-row" data-slug="${r.slug}">
      <span>${escapeHtml(r.name)}</span>
      <div class="row-actions">
        <button type="button" class="btn-save btn-open-restaurant">Manage menu</button>
        <button type="button" class="btn-delete btn-delete-restaurant">Delete</button>
      </div>
    </div>
  `).join("");

  listEl.querySelectorAll(".btn-open-restaurant").forEach((btn) => {
    btn.addEventListener("click", () => {
      const slug = btn.closest(".dev-item-row").dataset.slug;
      restaurantSelect.value = slug;
      onRestaurantSelectionChange();
    });
  });

  listEl.querySelectorAll(".btn-delete-restaurant").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const row = btn.closest(".dev-item-row");
      if (!confirm(`Delete "${row.querySelector("span").textContent}" and its whole menu?`)) return;
      await fetch(`/api/restaurants/${row.dataset.slug}`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ devCode: window.__devCode }),
      });
      await populateRestaurantSelect();
      if (CATEGORY_ORDER[currentIndex] === "restaurants" && !viewingRestaurant) loadRestaurants();
    });
  });
}

async function refreshRestaurantDevItemsList() {
  const listEl = document.getElementById("devItemsList");
  listEl.innerHTML = "Loading…";
  const res = await fetch(`/api/restaurants/${selectedRestaurantSlug}/items`);
  const items = await res.json();
  if (!items.length) {
    listEl.innerHTML = "<p class='form-note'>No menu items yet.</p>";
    return;
  }
  listEl.innerHTML = items.map((item) => `
    <div class="dev-item-row" data-slug="${item.slug}">
      <span>${escapeHtml(item.name)}</span>
      <input type="number" step="0.01" min="0" value="${item.price === "" ? "" : item.price}" placeholder="price">
      <div class="row-actions">
        <button type="button" class="btn-save">Save</button>
        <button type="button" class="btn-delete">Delete</button>
      </div>
    </div>
  `).join("");

  listEl.querySelectorAll(".btn-save").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const row = btn.closest(".dev-item-row");
      const price = row.querySelector("input").value;
      await fetch(`/api/restaurants/${selectedRestaurantSlug}/items/${row.dataset.slug}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ devCode: window.__devCode, price }),
      });
      refreshRestaurantDevItemsList();
      if (viewingRestaurant === selectedRestaurantSlug) openRestaurantMenu(selectedRestaurantSlug, categoryNameEl.textContent);
    });
  });

  listEl.querySelectorAll(".btn-delete").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const row = btn.closest(".dev-item-row");
      if (!confirm(`Delete "${row.querySelector("span").textContent}"?`)) return;
      await fetch(`/api/restaurants/${selectedRestaurantSlug}/items/${row.dataset.slug}`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ devCode: window.__devCode }),
      });
      refreshRestaurantDevItemsList();
      if (viewingRestaurant === selectedRestaurantSlug) openRestaurantMenu(selectedRestaurantSlug, categoryNameEl.textContent);
    });
  });
}

// non-restaurant categories: existing generic item list
async function refreshDevItemsList() {
  const category = itemCategorySelect.value;
  const listEl = document.getElementById("devItemsList");
  listEl.innerHTML = "Loading…";
  const res = await fetch(`/api/shop/${category}`);
  const items = await res.json();
  if (!items.length) {
    listEl.innerHTML = "<p class='form-note'>No items in this category yet.</p>";
    return;
  }
  listEl.innerHTML = items.map((item) => `
    <div class="dev-item-row" data-slug="${item.slug}" data-category="${category}">
      <span>${escapeHtml(item.name)}</span>
      <input type="number" step="0.01" min="0" value="${item.price === "" ? "" : item.price}" placeholder="price">
      <div class="row-actions">
        <button type="button" class="btn-save">Save</button>
        <button type="button" class="btn-delete">Delete</button>
      </div>
    </div>
  `).join("");

  listEl.querySelectorAll(".btn-save").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const row = btn.closest(".dev-item-row");
      const price = row.querySelector("input").value;
      await fetch(`/api/shop/${row.dataset.category}/${row.dataset.slug}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ devCode: window.__devCode, price }),
      });
      refreshDevItemsList();
      if (CATEGORY_ORDER[currentIndex] === row.dataset.category) loadItems(row.dataset.category);
    });
  });

  listEl.querySelectorAll(".btn-delete").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const row = btn.closest(".dev-item-row");
      if (!confirm(`Delete "${row.querySelector("span").textContent}"?`)) return;
      await fetch(`/api/shop/${row.dataset.category}/${row.dataset.slug}`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ devCode: window.__devCode }),
      });
      refreshDevItemsList();
      if (CATEGORY_ORDER[currentIndex] === row.dataset.category) loadItems(row.dataset.category);
    });
  });
}

addItemForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const statusEl = document.getElementById("addItemStatus");
  statusEl.textContent = "Saving…";

  const category = itemCategorySelect.value;
  const form = new FormData();
  form.append("devCode", window.__devCode);
  form.append("name", document.getElementById("itemName").value);
  form.append("description", document.getElementById("itemDescription").value);
  form.append("price", document.getElementById("itemPrice").value);
  form.append("image", document.getElementById("itemImage").files[0]);

  const url = category === "restaurants"
    ? `/api/restaurants/${selectedRestaurantSlug}/items`
    : `/api/shop/${category}`;

  const res = await fetch(url, { method: "POST", body: form });
  if (res.ok) {
    statusEl.textContent = "Item added.";
    addItemForm.reset();
    if (category === "restaurants") {
      refreshRestaurantDevItemsList();
      if (viewingRestaurant === selectedRestaurantSlug) openRestaurantMenu(selectedRestaurantSlug, categoryNameEl.textContent);
    } else {
      refreshDevItemsList();
      if (CATEGORY_ORDER[currentIndex] === category) loadItems(category);
    }
  } else {
    const data = await res.json().catch(() => ({}));
    statusEl.textContent = data.error || "Could not add item.";
  }
});

// ---------- init ----------

selectCategory(0);
